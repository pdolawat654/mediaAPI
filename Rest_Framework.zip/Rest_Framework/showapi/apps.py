from django.apps import AppConfig


class ShowapiConfig(AppConfig):
    name = 'showapi'
