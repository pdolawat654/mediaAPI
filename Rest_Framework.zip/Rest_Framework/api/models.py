from django.db import models
from django.db.models.signals import post_delete
from django.dispatch import receiver

class Prescription(models.Model):
    image=models.FileField(upload_to="prescriptions")
    email=models.TextField(default=None)

class ProfilePic(models.Model):
    image=models.FileField(upload_to="profilePics")
    email=models.TextField(default=None)


@receiver(post_delete, sender=Prescription)
def submission_delete(sender, instance, **kwargs):
    instance.image.delete(False) 