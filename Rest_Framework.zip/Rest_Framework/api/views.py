from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.decorators import api_view
from .models import Prescription,ProfilePic
from .serializers import PrescriptionSerializer,ProfilePicSerializer
from django.views.decorators.csrf import csrf_exempt


@api_view(['GET'])
def prescriptionDetail(request,email):
    prescription=Prescription.objects.filter(email=email)
    serializer=PrescriptionSerializer(prescription,many=True)

    return Response(serializer.data)


@api_view(['GET'])
def prescription(request):
    prescription=Prescription.objects.all()
    serializer=PrescriptionSerializer(prescription,many=True)

    return Response(serializer.data)


@api_view(['GET'])
def getProfilePic(request,email):
    profilePic=ProfilePic.objects.filter(email=email).last()
    serializer=ProfilePicSerializer(profilePic,many=False)

    return Response(serializer.data)

@csrf_exempt
@api_view(['POST'])
def addPrescription(request):
    serializer=PrescriptionSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()

    return Response(serializer.data)


@api_view(['DELETE'])
def deletePrescription(request, pk):
    prescription=Prescription.objects.filter(id=pk)
    prescription.delete()
    return Response("ITEM DELETED SUCCESSFULLY")

@api_view(['GET'])
def getMediaByID(request, pk):
    prescription=Prescription.objects.filter(id=pk).first()
    serializer=PrescriptionSerializer(prescription,many=False)
    return Response(serializer.data)

@csrf_exempt
@api_view(['POST'])
def addProfilePic(request):
    serializer=ProfilePicSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
    return Response(serializer.data)