from django.urls import path
from . import views
urlpatterns=[
    path('getMediaForUser/<str:email>/',views.prescriptionDetail,name="prescriptionDetail"),
    path('addMedia',views.addPrescription,name="addPrescription"),
    path('deleteMedia/<str:pk>',views.deletePrescription,name="deletePrescription"),
    path('getMediaByID/<str:pk>',views.getMediaByID,name="deletePrescription"),
    path('media/',views.prescription,name="prescription"),
    # path('addProfilePic',views.addProfilePic,name="addProfilePic"),
    # path('getProfilePic/<str:email>/',views.getProfilePic,name="getProfilePic"),
    

]