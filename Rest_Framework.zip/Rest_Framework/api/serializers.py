from rest_framework import serializers
from .models import Prescription,ProfilePic

class PrescriptionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Prescription
        fields='__all__'

class ProfilePicSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProfilePic
        fields='__all__'